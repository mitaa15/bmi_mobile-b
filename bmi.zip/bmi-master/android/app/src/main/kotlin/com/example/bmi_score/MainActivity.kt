package com.example.bmi_score

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
