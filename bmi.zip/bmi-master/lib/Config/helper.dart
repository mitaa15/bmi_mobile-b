import 'package:bmi_score/Config/hexColor.dart';

class Hellper {
 
}
